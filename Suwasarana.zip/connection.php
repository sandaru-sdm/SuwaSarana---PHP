<?php

class Database{

    public static $connection;

    public static function setUpConnection(){
        if(!isset(Database::$connection)){
            Database::$connection = 
            new mysqli("sql307.epizy.com","epiz_33398472","444JMKHf7xD","epiz_33398472_suwasarana","3306");
        }
    }

    public static function iud($q){
        Database::setUpConnection();
        Database::$connection->query($q);
    }

    public static function search($q){
        Database::setUpConnection();
        $resultset = Database::$connection->query($q);
        return $resultset;
    }

}

$conn = mysqli_connect("sql307.epizy.com","epiz_33398472","444JMKHf7xD","epiz_33398472_suwasarana","3307");

?>